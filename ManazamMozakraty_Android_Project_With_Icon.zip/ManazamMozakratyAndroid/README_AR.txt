منظم مذاكرتي - مشروع Android

هذا المشروع يحول نسخة الويب الحالية إلى تطبيق Android بسيط باستخدام WebView.
ملف التطبيق موجود في:
app/src/main/assets/index.html

لإخراج AAB للنشر على Google Play يحتاج المشروع إلى Android SDK/Gradle وبيئة بناء Android، ثم Build > Generate Signed Bundle / APK > Android App Bundle.

مهم: قبل النشر النهائي يجب تجهيز أيقونة التطبيق، سياسة الخصوصية، بيانات Google Play، واختبار التطبيق على الجهاز.
